---
name: make-interface-reference
description: This skill should be used when the user asks about "Make CLI", "make-cli", "Make MCP server", "Make MCP tools", "MCP token", "Make OAuth", "scenario as tool", "MCP scopes", "Make API access", "connect Make to Claude", "scenario not appearing", "MCP timeout", "MCP connection refused", or discusses configuring, troubleshooting, or understanding how an AI agent connects to Make via the Make CLI or the Make MCP server. Provides technical reference for both interfaces, including install, authentication, scopes, access control, invocation syntax, and troubleshooting.
license: MIT
compatibility: Requires a Make.com account with permissions to create scenarios. Works with any agent that supports either shell access (for the Make CLI) or MCP tool calling.
metadata:
  author: Make
  version: "0.1.3"
  homepage: https://www.make.com
  repository: https://github.com/integromat/make-skills
---

# Make Interface Reference


AI agents interact with Make through the Make MCP server (`https://mcp.make.com`), a hosted MCP service called via native tool invocation. Configure it as described below.


## Make MCP server

Install, authenticate, scopes, access control, transports, timeouts, configuring scenarios as MCP tools: see **[mcp-install-and-auth.md](./references/mcp-install-and-auth.md)**.

Transport comparison and URL construction: see **[transport-details.md](./references/transport-details.md)**.

## Troubleshooting

| Issue | Solution |
|-------|----------|
| No scenarios appearing as tools | Verify scenario is active, scheduled on-demand, and the authenticated user/token has the required scope. |
| Permission denied | For MCP token auth: check token scopes (`mcp:use` plus any management scopes). For OAuth: re-consent with the needed scopes. |
| MCP connection refused / timeout | Verify the zone URL pattern matches the auth mode — token-in-path: `https://<ZONE>/mcp/u/<TOKEN>[/<TRANSPORT>]`; header auth: `https://<ZONE>/mcp[/<TRANSPORT>]` with `Authorization: Bearer <TOKEN>`. For long-running management tools, use `/sse`. Details in [mcp-install-and-auth.md](./references/mcp-install-and-auth.md). |
| Stale MCP tool list | Reconnect the MCP client to refresh available tools. |


## Resources

- **[mcp-install-and-auth.md](./references/mcp-install-and-auth.md)** — Make MCP server connection methods, scopes, access control.
- **[transport-details.md](./references/transport-details.md)** — Transport comparison, URL construction, zone list.
- **[Make MCP Server docs](https://developers.make.com/mcp-server)** — Official documentation.

## Related skills

- **make-scenario-building** — Scenario design: app discovery, module selection, routing, error handling, deployment.
- **make-module-configuring** — Module configuration: parameters, connections, mapping, webhooks, data stores, validation.
